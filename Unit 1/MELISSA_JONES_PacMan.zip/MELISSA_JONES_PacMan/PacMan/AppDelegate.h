//
//  AppDelegate.h
//  PacMan
//
//  Created by squeak on 1/16/18.
//  Copyright © 2018 Melissa Jones. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

