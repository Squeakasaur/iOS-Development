//
//  main.m
//  MELISSA_JONES_DemoUnit3
//
//  Created by squeak on 2/1/18.
//  Copyright © 2018 Melissa Jones. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
